<?php
if ($level > 2) {
	pesanlink('Maaf! Ini bukan wilayah Anda.','../keluar.php');
}
?>