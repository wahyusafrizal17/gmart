<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--	<meta content='Download Program Aplikasi PHP sepuasnya, hanya di codeego.com' name='description'/>
    <meta content='https://www.codeego.com/' property='og:url'/>
===============================================================================================-->	
	<link rel="icon" type="image/png" href="log_asset/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="log_asset/vendor/bootstrap/css/bootstrap.min.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Invoice</title>
</head>

<body>
<br></br>    
<br></br>
<br></br>
<div class="container">
    <h3 class="alert alert-danger">
        Notice!
    </h3>
    <p class="alert alert-info">Harap lakukan pembayaran 100% dikarenakan sistem telah selesai dibangun.<br>Kami mengorbankan banyak hal yang bermanfaat lainnya untuk mengembangkan program ini. 
    <br>Perbaikan maupun pengembangan sistem akan berhenti dilanjutkan apabila pembayaran belum dilakukan.
    <br>Atas Perhatian dan kerjasamanya kami ucapkan Terima kasih.</p>
</div>    
</body>
</html>
