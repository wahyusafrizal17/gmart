<?php
if ($level > 3) {
	pesanlink('Maaf! Ini bukan wilayah Anda.','../keluar.php');
}
?>