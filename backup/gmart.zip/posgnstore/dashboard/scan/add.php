<?php
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
	$editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

//MENYIMPAN NOMOR FAKTUR ----
if ((isset($_POST["MM_faktur"])) && ($_POST["MM_faktur"] == "form2")) {
	$insertSQL = sprintf(
		"INSERT INTO faktur (tglfaktur, statusfaktur, kodefaktur, addedfaktur, addbyfaktur, adminfaktur, periode) VALUES (%s, %s, %s, %s, %s, %s, %s)",
		GetSQLValueString($koneksi, $today, "date"),
		GetSQLValueString($koneksi, 'N', "text"),
		GetSQLValueString($koneksi, $kodeacak, "text"),
		GetSQLValueString($koneksi, time(), "int"),
		GetSQLValueString($koneksi, $ID, "int"),
		GetSQLValueString($koneksi, $nama, "text"),
		GetSQLValueString($koneksi, $ta, "text")
	);


	$Result1 = mysqli_query($koneksi, $insertSQL) or die(mysqli_error($koneksi));

	if ($Result1) {
		refresh('?page=scan/add');
	}
}


$query_Faktur = sprintf(
	"SELECT * FROM faktur WHERE tglfaktur = %s AND addbyfaktur = %s AND periode = %s AND statusfaktur = %s ORDER BY idfaktur DESC",
	GetSQLValueString($koneksi, $tglsekarang, "date"),
	GetSQLValueString($koneksi, $ID, "int"),
	GetSQLValueString($koneksi, $ta, "text"),
	GetSQLValueString($koneksi, 'N', "text")
);
$Faktur = mysqli_query($koneksi, $query_Faktur) or die(mysqli_error($koneksi));
$row_Faktur = mysqli_fetch_assoc($Faktur);
$totalRows_Faktur = mysqli_num_rows($Faktur);
//MEMBUAT NILAI FAKTUR

$faktur = $row_Faktur['kodefaktur'];
if (isset($_GET['faktur'])) {
	$faktur = $_GET['faktur'];
}
//---------------------------

$colname_search = "--1";
if (isset($_POST['search'])) {
	$colname_search = $_POST['search'];
	require('faktur.php');
}

$query_search = sprintf(
	"SELECT * FROM produk WHERE stok > 0 AND (kodeproduk = %s OR namaproduk LIKE %s) LIMIT 10",
	GetSQLValueString($koneksi, $colname_search, "text"),
	GetSQLValueString($koneksi, "%" . $colname_search . "%", "text")
);
$search = mysqli_query($koneksi, $query_search) or die(mysqli_error($koneksi));
$row_search = mysqli_fetch_assoc($search);
$totalRows_search = mysqli_num_rows($search);

//JIKA HASIL PENCARIAN 1 PRODUK MAKA LANGSUNG SIMPAN
if ($totalRows_search == 1) {
	require('faktur.php');

	//SEBELUM ITU, DICEK JIKA PRODUK YG SAMA MAKA TAMBAHKAN STOK SAJA

	$cek =  sprintf(
		"SELECT kode, faktur, qty FROM transaksitemp WHERE kode = %s AND faktur = %s",
		GetSQLValueString($koneksi, $row_search['kodeproduk'], "text"),
		GetSQLValueString($koneksi, $faktur, "text")
	);
	$rs_cek = mysqli_query($koneksi, $cek) or die(mysqli_error($koneksi));
	$row_rs_cek = mysqli_fetch_assoc($rs_cek);
	$totalRows_rs_cek = mysqli_num_rows($rs_cek);

	if ($totalRows_rs_cek > 0) {
		//update / tambah qty produk
		if ($row_rs_cek['qty'] >= $row_search['stok']) {
			danger('Oops!', '' . $row_search['namaproduk'] . " - Stok terbatas!! Maks. " . $row_rs_cek['qty'] . ' ');
		} else {
			$stok = sprintf(
				"UPDATE transaksitemp SET qty = qty + 1 WHERE faktur = %s AND kode = %s",
				GetSQLValueString($koneksi, $faktur, "text"),
				GetSQLValueString($koneksi, $row_search['kodeproduk'], "text")
			);


			$hasilstok = mysqli_query($koneksi, $stok) or die(mysqli_error($koneksi));
		}
	} else {
		require('faktur.php');

		$insertSQL = sprintf(
			"INSERT INTO transaksitemp (`faktur`, `tanggal`, `kode`, `nama`, `harga`, `hargadasar`, `diskon`,`qty`, `added`, `addby`, `admintt`, `stt`, `periode`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
			GetSQLValueString($koneksi, $faktur, "text"),
			GetSQLValueString($koneksi, $today, "date"),
			GetSQLValueString($koneksi, $row_search['kodeproduk'], "text"),
			GetSQLValueString($koneksi, $row_search['namaproduk'], "text"),
			GetSQLValueString($koneksi, $row_search['hargajual'], "double"),
			GetSQLValueString($koneksi, $row_search['hargadasar'], "double"),
			GetSQLValueString($koneksi, 0, "double"),
			GetSQLValueString($koneksi, 1, "int"),
			GetSQLValueString($koneksi, time(), "int"),
			GetSQLValueString($koneksi, $ID, "int"),
			GetSQLValueString($koneksi, $nama, "text"),
			GetSQLValueString($koneksi, $row_search['statusproduk'], "text"),
			GetSQLValueString($koneksi, $ta, "text")
		);


		$Result1 = mysqli_query($koneksi, $insertSQL) or die(mysqli_error($koneksi));
	} //tutup Cek Produk yg sudah ada	  
} //tutup pencarian produk


$query_trans = sprintf(
	"SELECT * FROM transaksitemp INNER JOIN produk ON kode = kodeproduk WHERE faktur = %s ORDER BY transaksitemp.id ASC",
	GetSQLValueString($koneksi, $faktur, "text")
);
$trans = mysqli_query($koneksi, $query_trans) or die(mysqli_error($koneksi));
$row_trans = mysqli_fetch_assoc($trans);
$totalRows_trans = mysqli_num_rows($trans);

//MENGUBAH NILAI QTY PADA TEMPTRANSAKSI
if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "formCombobox")) {


	$cek =  sprintf(
		"SELECT stok FROM produk WHERE kodeproduk = %s",
		GetSQLValueString($koneksi, $_POST['kodeCombo'], "text")
	);
	$rs_cek = mysqli_query($koneksi, $cek) or die(mysqli_error($koneksi));
	$row_rs_cek = mysqli_fetch_assoc($rs_cek);
	$totalRows_rs_cek = mysqli_num_rows($rs_cek);

	if ($_POST['qtyupdate'] >= $row_rs_cek['stok']) {
		danger('Oops!', "Stok terbatas!! Maks. " . $row_rs_cek['stok'] . ' ');
	} else {
		$stok = sprintf(
			"UPDATE transaksitemp SET qty = %s WHERE faktur = %s AND kode = %s",
			GetSQLValueString($koneksi, $_POST['qtyupdate'], "int"),
			GetSQLValueString($koneksi, $faktur, "text"),
			GetSQLValueString($koneksi, $_POST['kodeCombo'], "text")
		);


		$hasilstok = mysqli_query($koneksi, $stok) or die(mysqli_error($koneksi));
	}

	//untuk reload update barang	

	$query_trans = sprintf(
		"SELECT * FROM transaksitemp INNER JOIN produk ON kode = kodeproduk WHERE faktur = %s ORDER BY transaksitemp.id ASC",
		GetSQLValueString($koneksi, $faktur, "text")
	);
	$trans = mysqli_query($koneksi, $query_trans) or die(mysqli_error($koneksi));
	$row_trans = mysqli_fetch_assoc($trans);
	$totalRows_trans = mysqli_num_rows($trans);
}

//-----------------

if ($totalRows_search > 1) {
	for ($i = 1; $i <= $totalRows_search; $i++) {
		if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "formx" . $i)) {
			//SEBELUM ITU, DICEK JIKA PRODUK YG SAMA MAKA TAMBAHKAN STOK SAJA

			$cek =  sprintf(
				"SELECT kode, faktur, qty FROM transaksitemp WHERE kode = %s AND faktur = %s",
				GetSQLValueString($koneksi, $_POST['kodeproduk'], "text"),
				GetSQLValueString($koneksi, $faktur, "text")
			);
			$rs_cek = mysqli_query($koneksi, $cek) or die(mysqli_error($koneksi));
			$row_rs_cek = mysqli_fetch_assoc($rs_cek);
			$totalRows_rs_cek = mysqli_num_rows($rs_cek);

			if ($totalRows_rs_cek > 0) {
				//update / tambah qty produk
				if ($row_rs_cek['qty'] >= $_POST['stok']) {
					danger('Oops!', '' . $_POST['namaproduk'] . " - Stok terbatas!! Maks. " . $row_rs_cek['qty'] . ' ');
				} else {
					$stok = sprintf(
						"UPDATE transaksitemp SET qty = qty + 1 WHERE faktur = %s AND kode = %s",
						GetSQLValueString($koneksi, $faktur, "text"),
						GetSQLValueString($koneksi, $_POST['kodeproduk'], "text")
					);


					$hasilstok = mysqli_query($koneksi, $stok) or die(mysqli_error($koneksi));
				}
			} else {
				$insertSQL = sprintf(
					"INSERT INTO transaksitemp (`faktur`, `tanggal`, `kode`, `nama`, `harga`, `hargadasar`, `diskon`,`qty`, `added`, `addby`, `admintt`, `stt`, `periode`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
					GetSQLValueString($koneksi, $faktur, "text"),
					GetSQLValueString($koneksi, $today, "date"),
					GetSQLValueString($koneksi, $row_search['kodeproduk'], "text"),
					GetSQLValueString($koneksi, $row_search['namaproduk'], "text"),
					GetSQLValueString($koneksi, $row_search['hargajual'], "double"),
					GetSQLValueString($koneksi, $row_search['hargadasar'], "double"),
					GetSQLValueString($koneksi, 0, "double"),
					GetSQLValueString($koneksi, 1, "int"),
					GetSQLValueString($koneksi, time(), "int"),
					GetSQLValueString($koneksi, $ID, "int"),
					GetSQLValueString($koneksi, $nama, "text"),
					GetSQLValueString($koneksi, $row_search['statusproduk'], "text"),
					GetSQLValueString($koneksi, $ta, "text")
				);


				$Result1 = mysqli_query($koneksi, $insertSQL) or die(mysqli_error($koneksi));
			} //tutup Cek Produk yg sudah ada  */
		}
		//untuk reload update barang

		$query_trans = sprintf(
			"SELECT * FROM transaksitemp INNER JOIN produk ON kode = kodeproduk WHERE faktur = %s ORDER BY transaksitemp.id ASC",
			GetSQLValueString($koneksi, $faktur, "text")
		);
		$trans = mysqli_query($koneksi, $query_trans) or die(mysqli_error($koneksi));
		$row_trans = mysqli_fetch_assoc($trans);
		$totalRows_trans = mysqli_num_rows($trans);
	}
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "formCari")) {
	//SEBELUM ITU, DICEK JIKA PRODUK YG SAMA MAKA TAMBAHKAN STOK SAJA

	$cek =  sprintf(
		"SELECT kode, faktur, qty FROM transaksitemp WHERE kode = %s AND faktur = %s",
		GetSQLValueString($koneksi, $_POST['kodeproduk'], "text"),
		GetSQLValueString($koneksi, $faktur, "text")
	);
	$rs_cek = mysqli_query($koneksi, $cek) or die(mysqli_error($koneksi));
	$row_rs_cek = mysqli_fetch_assoc($rs_cek);
	$totalRows_rs_cek = mysqli_num_rows($rs_cek);

	if ($totalRows_rs_cek > 0) {
		//update / tambah qty produk
		if ($row_rs_cek['qty'] >= $_POST['stok']) {
			danger('Oops!', '' . $_POST['namaproduk'] . " - Stok terbatas!! Maks. " . $row_rs_cek['qty'] . ' ');
		} else {
			$stok = sprintf(
				"UPDATE transaksitemp SET qty = qty + 1 WHERE faktur = %s AND kode = %s",
				GetSQLValueString($koneksi, $faktur, "text"),
				GetSQLValueString($koneksi, $_POST['kodeproduk'], "text")
			);


			$hasilstok = mysqli_query($koneksi, $stok) or die(mysqli_error($koneksi));
		}
	} else {
		$insertSQL = sprintf(
			"INSERT INTO transaksitemp (`faktur`, `tanggal`, `kode`, `nama`, `harga`, `hargadasar`, `diskon`,`qty`, `added`, `addby`, `admintt`, `stt`, `periode`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
			GetSQLValueString($koneksi, $faktur, "text"),
			GetSQLValueString($koneksi, $today, "date"),
			GetSQLValueString($koneksi, $_POST['kodeproduk'], "text"),
			GetSQLValueString($koneksi, $_POST['namaproduk'], "text"),
			GetSQLValueString($koneksi, $_POST['hargajual'], "double"),
			GetSQLValueString($koneksi, $_POST['hargadasar'], "double"),
			GetSQLValueString($koneksi, 0, "double"),
			GetSQLValueString($koneksi, 1, "int"),
			GetSQLValueString($koneksi, time(), "int"),
			GetSQLValueString($koneksi, $ID, "int"),
			GetSQLValueString($koneksi, $nama, "text"),
			GetSQLValueString($koneksi, $_POST['statusproduk'], "text"),
			GetSQLValueString($koneksi, $ta, "text")
		);


		$Result1 = mysqli_query($koneksi, $insertSQL) or die(mysqli_error($koneksi));
	} //tutup Cek Produk yg sudah ada  */

	//untuk reload update barang

	$query_trans = sprintf(
		"SELECT * FROM transaksitemp INNER JOIN produk ON kode = kodeproduk WHERE faktur = %s ORDER BY transaksitemp.id ASC",
		GetSQLValueString($koneksi, $faktur, "text")
	);
	$trans = mysqli_query($koneksi, $query_trans) or die(mysqli_error($koneksi));
	$row_trans = mysqli_fetch_assoc($trans);
	$totalRows_trans = mysqli_num_rows($trans);
}



//--------------- UBAH STATUS Y PADA FAKTUR --------------
if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "formSelesai")) {
	$Start = mysqli_query($koneksi, "START TRANSACTION") or die(errorQuery(mysqli_error($koneksi)));
	if (str_replace(".", "", $_POST["bayar"]) >= $_POST["textfield3"]) {

		$query_temp = sprintf(
			"SELECT * FROM transaksitemp WHERE faktur = %s ORDER BY id ASC",
			GetSQLValueString($koneksi, $faktur, "text")
		);
		$temp = mysqli_query($koneksi, $query_temp) or die(mysqli_error($koneksi));
		$row_temp = mysqli_fetch_assoc($temp);
		$totalRows_temp = mysqli_num_rows($temp);

		do {
			$tempSQL = sprintf(
				"INSERT INTO transaksidetail (`faktur`, `tanggal`, `kode`, `nama`, `harga`, `hargadasar`, `diskon`, `qty`, `added`, `addby`, `admintd`, `stt`, `periode`) VALUES (%s,%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
				GetSQLValueString($koneksi, $row_temp['faktur'], "text"),
				GetSQLValueString($koneksi, $row_temp['tanggal'], "date"),
				GetSQLValueString($koneksi, $row_temp['kode'], "text"),
				GetSQLValueString($koneksi, $row_temp['nama'], "text"),
				GetSQLValueString($koneksi, $row_temp['harga'], "double"),
				GetSQLValueString($koneksi, $row_temp['hargadasar'], "double"),
				GetSQLValueString($koneksi, $row_temp['diskon'], "double"),
				GetSQLValueString($koneksi, $row_temp['qty'], "int"),
				GetSQLValueString($koneksi, $row_temp['added'], "int"),
				GetSQLValueString($koneksi, $row_temp['addby'], "int"),
				GetSQLValueString($koneksi, $row_temp['admintt'], "text"),
				GetSQLValueString($koneksi, $row_temp['stt'], "text"),
				GetSQLValueString($koneksi, $row_temp['periode'], "text")
			);

			$stok = sprintf(
				"UPDATE produk SET stok = stok - %s WHERE kodeproduk = %s",
				GetSQLValueString($koneksi, $row_temp['qty'], "int"),
				GetSQLValueString($koneksi, $row_temp['kode'], "text")
			);
			//edit stok										 

			$hasilstok = mysqli_query($koneksi, $stok) or die(mysqli_error($koneksi));

			$deleteSQL = sprintf(
				"DELETE FROM transaksitemp WHERE id=%s",
				GetSQLValueString($koneksi, $row_temp['id'], "text")
			);

			//simpan

			$Resulttemp = mysqli_query($koneksi, $tempSQL) or die(mysqli_error($koneksi));

			//delete

			$del = mysqli_query($koneksi, $deleteSQL) or die(mysqli_error($koneksi));
		} while ($row_temp = mysqli_fetch_assoc($temp));



		$updateSQL = sprintf(
			"UPDATE faktur SET jenisbayar=%s, statusfaktur=%s, kembalian=%s, potongan=%s, totalbayar=%s, nohp=%s, namapelanggan=%s WHERE kodefaktur = %s",
			GetSQLValueString($koneksi, $_POST['jenisbayar'], "text"),
			GetSQLValueString($koneksi, 'Y', "text"),
			GetSQLValueString($koneksi, $_POST['balek'], "double"),
			GetSQLValueString($koneksi, $_POST['diskon'], "double"),
			GetSQLValueString($koneksi,	str_replace(".", "", $_POST['bayar']), "double"),
			GetSQLValueString($koneksi, $_POST['nohp'], "double"),
			GetSQLValueString($koneksi, $_POST['namapelanggan'], "text"),
			GetSQLValueString($koneksi, $faktur, "text")
		);


		$Result1 = mysqli_query($koneksi, $updateSQL) or die(mysqli_error($koneksi));

		if ($Result1) {
			$Commit = mysqli_query($koneksi, "COMMIT") or die(errorQuery(mysqli_error($koneksi)));
			require('faktur.php');
			echo "<script>
		window.open('report/kwitansi.php?id=$faktur', '', 'width=600,height=600');
		document.location.href='?page=scan/add';
	</script>";
		}
	} else {
		echo "<script>
		alert('Oops!, Pembayaran masih minus!');
	</script>";
	}
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "formDiskon")) {
	$stok = sprintf(
		"UPDATE transaksitemp SET diskon = %s WHERE faktur = %s AND kode = %s",
		GetSQLValueString($koneksi, $_POST['diskon'], "text"),
		GetSQLValueString($koneksi, $_POST['faktur'], "text"),
		GetSQLValueString($koneksi, $_POST['kodeproduk'], "text")
	);


	$hasilstok = mysqli_query($koneksi, $stok) or die(mysqli_error($koneksi));

	//untuk reload update barang

	$query_trans = sprintf(
		"SELECT * FROM transaksitemp INNER JOIN produk ON kode = kodeproduk WHERE faktur = %s ORDER BY transaksitemp.id ASC",
		GetSQLValueString($koneksi, $faktur, "text")
	);
	$trans = mysqli_query($koneksi, $query_trans) or die(mysqli_error($koneksi));
	$row_trans = mysqli_fetch_assoc($trans);
	$totalRows_trans = mysqli_num_rows($trans);
}
?>


<div class="row">
	<div class="col-md-8 col-xs-12">
		<p>SCAN BARCODE HERE <span class="small">Pastikan Stok Barang tidak kosong</span></p>
		<form id="form1" name="form1" method="post" action="" autocomplete="off">

			<div class="input-group">

				<input type="text" name="search" placeholder="Masukkan Kode / Nama Produk" class="form-control" autofocus required>

				<span class="input-group-btn">
					<button type="submit" class="btn btn-info btn-flat">Search</button>
					<a href="camera.php" class="btn btn-primary btn-block"><span class="fa fa-barcode"></span> Scan Barcode</a>
				</span>
			</div>
		</form>
	</div>
	<div class="col-md-2">
		<a href="?page=tabulasi/penjualan" class="btn btn-warning btn-sm btn-block"><span class="fa fa-ticket"></span> Faktur Sebelumnya</a></span> <a href="" class="btn btn-info btn-sm btn-block" data-toggle="modal" data-target="#exampleModal"><span class="fa fa-ticket"></span> Add Product</a></span>

	</div>
	<div class="col-md-2">
		<div class="small-box bg-red text-center">

			<label class="small">NO. FAKTUR</label>
			<p style="font-size: 30px;"><?= $faktur; ?></p>

		</div>
	</div>
</div>
<div class="row">
	<!-- Pencarian produk jika lebih dari 1 -->
	<div class="col-md-8">
		<?php if ($totalRows_search > 1) { ?>
			<table width="100%" class="table table-sm table-condensed table-hover">
				<tr bgcolor="#663399">
					<td>
						<div align="center" class="style1"><strong>NO.</strong></div>
					</td>
					<td>
						<div align="center" class="style1"><strong>PRODUK</strong></div>
					</td>
					<td>
						<div align="center" class="style1"><strong>ACTION</strong></div>
					</td>
				</tr>
				<?php $no = 1;
				do { ?>
					<tr>
						<td>
							<div align="center"><?php echo $no; ?></div>
						</td>
						<td class="text-uppercase"><?php echo $row_search['kodeproduk']; ?> - <?php echo $row_search['namaproduk']; ?><br />
							Rp. <?php echo number_format($row_search['hargajual']); ?> ( <?php echo $row_search['stok']; ?> <?php echo $row_search['satuan']; ?> )</td>
						<td>

							<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
								<input type="hidden" name="kodeproduk" value="<?= $row_search['kodeproduk']; ?>" />
								<input type="hidden" name="namaproduk" value="<?= $row_search['namaproduk']; ?>" />
								<input type="hidden" name="hargajual" value="<?= $row_search['hargajual']; ?>" />
								<input type="hidden" name="hargadasar" value="<?= $row_search['hargadasar']; ?>" />
								<input type="hidden" name="stok" value="<?= $row_search['stok']; ?>" />
								<input type="hidden" name="statusproduk" value="<?= $row_search['statusproduk']; ?>" />
								<button type="submit" name="button" class="btn btn-block btn-success"><span class="fa fa-shopping-cart"></span> Add Cart</button>
								<input type="hidden" name="MM_insert" value="formCari" />
							</form>
						</td>
					</tr>
				<?php
					$no++;
				} while ($row_search = mysqli_fetch_assoc($search)); ?>
			</table>
		<?php } else { ?>
			<!-- <p class="text-danger padding-10mm">Perhatian! Pastikan bahwa stok barang tidak kosong</p> -->
		<?php	} ?>
	</div> <!-- col -->

	<div class="clearfix"></div>
	<div class="col-md-8 col-xs-12">

		<?php if ($totalRows_trans > 0) { ?>
			<table width="100%" class="table table-sm table-condensed table-striped table-hover">
				<thead>
					<tr bgcolor="#006699">
						<th width="2%">
							<div align="center"><span class="style1">NO.</span></div>
						</th>
						<th width="43%">
							<div align="center"><span class="style1">PRODUK</span></div>
						</th>
						<th width="10%">
							<div align="center"><span class="style1">QTY</span></div>
						</th>
						<th width="23%">
							<div align="center"><span class="style1">PRICE</span></div>
						</th>
						<th width="23%">
							<div align="center"><span class="style1">SUBTOTAL</span></div>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$item = 0;
					$harga = 0;
					$diskon = 0;
					$no = 1;
					$idmodal = 1;
					do { ?>
						<tr style="font-size:22px">
							<td>
								<div align="center"><?php echo $no; ?></div>
							</td>

							<td class="text-uppercase"><a href="#" data-toggle="modal" data-target="#modal-default<?= $idmodal; ?>">
									<span class="btn-block"><?php echo $row_trans['nama']; ?> <span class="text-danger small">
											<?php if ($row_trans['diskon'] > 0) { ?>
												( Disc : Rp. <?= number_format($row_trans['diskon'], 0, ",", "."); ?> )
											<?php } ?>
										</span>
									</span>
								</a>
								<!-- Modal -->
								<div class=" modal fade" id="modal-default<?= $idmodal; ?>">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span></button>
												<h4 class="modal-title">DETAIL : <?php echo $row_trans['kode']; ?> - <?php echo $row_trans['nama']; ?></h4>
											</div>
											<div class="modal-body">
												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="">SETTING QTY</label>

															<?php if ($row_trans['stok'] > 0) { ?>
																<form id="form<?= $no; ?>" name="formCombobox" method="post" action="">

																	<div class="input-group">
																		<input type="number" name="qtyupdate" value="<?php echo htmlentities($row_trans['qty'], ENT_COMPAT, 'utf-8'); ?>" placeholder="Jumlah Beli" class="form-control input-lg" autofocus />
																		<span class="input-group-btn">
																			<button type="submit" class="btn btn-warning btn-lg">UBAH</button>
																		</span>
																	</div>

																	<input type="hidden" name="MM_update" value="formCombobox" />
																	<input type="hidden" name="kodeCombo" value="<?= $row_trans['kode']; ?>" />
																</form>
															<?php } else { ?>
																<a href="?page=manage/addget&search=<?= $row_trans['kode']; ?>" target="_blank" class="form-control input-lg">Klik disini untuk Tambah Stok Darurat!</a>
															<?php } ?>

															<?php $dis = 0 * $row_trans['qty'];
															number_format($dis); ?>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label for="">SUB TOTAL</label>
															<input type="text" class="form-control input-lg" name="" value="<?php $sub = $row_trans['harga'] * $row_trans['qty'];
																															echo number_format($sub); ?>" readonly>

														</div>
													</div>
												</div>


												<div class="form-group">
													<label for="">BERIKAN POTONGAN HARGA</label>
													<form action="<?php echo $editFormAction; ?>" method="post" name="formDiskon" id="formDiskon">
														<div class="input-group">
															<input type="number" name="diskon" value="<?php echo htmlentities($row_trans['diskon'], ENT_COMPAT, 'utf-8'); ?>" placeholder="Potongan" class="form-control input-lg" autofocus />
															<span class="input-group-btn">
																<button type="submit" class="btn btn-info btn-lg">Apply</button>
															</span>
														</div>
														<input type="hidden" name="MM_update" value="formDiskon" />
														<input type="hidden" name="kodeproduk" value="<?= $row_trans['kode']; ?>" />
														<input type="hidden" name="faktur" value="<?= $row_trans['faktur']; ?>" />
													</form>

												</div>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
												<a href="?page=scan/delete&id=<?php echo $row_trans['id'] ?>" class="btn btn-danger  btn-flat"><span class="fa fa-close"></span> Hapus</a>
											</div>
										</div>
										<!-- /.modal-content -->
									</div>
									<!-- /.modal-dialog -->
								</div>
								<!-- /.modal -->
							</td>
							<td align="center">
								<a href="#" data-toggle="modal" data-target="#modal-default<?= $idmodal; ?>">
									<span class="btn-block"><?= $row_trans['qty']; ?> </span>
								</a>
							</td>
							<td align="right">Rp. <?= number_format($row_trans['harga'], 0, ",", "."); ?></td>
							<td align="right">Rp. <?php $subtotal = ($row_trans['harga'] * $row_trans['qty']) - $row_trans['diskon'];
													echo number_format($subtotal, 0, ",", "."); ?></td>
						</tr>
					<?php
						$item += $row_trans['qty'];
						$harga += $sub;
						$diskon += $row_trans['diskon'];
						$no++;
						$idmodal++;
					} while ($row_trans = mysqli_fetch_assoc($trans)); ?>
					<?php global $item; ?>
					<?php global $harga; ?>
					<?php global $diskon; ?>
					<?php global $grand;
					$grand = $harga - $diskon; ?>
					<tr>
						<td colspan="3"></td>
						<td align="right"><strong>POTONGAN</strong></td>
						<td align="right">Rp. <?= number_format($diskon); ?>

						</td>
					</tr>



				</tbody>
			</table>

			<?php if (!empty($faktur)) { ?>
				<form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
					<button class="btn btn-lg btn-info btn-block"><span class="fa fa-plus-circle"></span> Buat Transaksi Baru</button>
					<input type="hidden" name="MM_faktur" value="form2" />
				</form>
				<p></p>
				<a href="?page=pengeluaran/add" class="btn btn-danger btn-block btn-lg">Input Data Pengeluaran <span class="fa fa-sign-out"></span></a>
			<?php } ?>
		<?php } else {
			danger('Belum ada Item', 'Silahkan Cari dan Masukkan data Barang');
		} ?>




	</div>
	<?php if ($totalRows_trans > 0) { ?>
		<div class="col-md-4 col-xs-12">
			<p style="font-size: 40px; background-color:darkcyan; padding-right:15px; color:white;" class="text-right">Rp. <?= number_format($grand); ?></p>

			<form method="post" name="formSelesai" action="<?php echo $editFormAction; ?>" autocomplete="off">
				<div class="small-box bg-purple">
					<div class="inner">

						<div class="table-responsive">
							<table class="table no-border">
								<tr>
									<td width="40%"><strong>UANG BAYAR</strong></td>
									<td><input type="hidden" name="textfield3" id="gt" value="<?= $grand; ?>" />
										<input style="font-size: 30px;" type="text" name="bayar" id="tanpa-rupiah" placeholder="<?= $grand; ?>" class="form-control text-right" onkeyup="kembalian();" autofocus required />
									</td>
								</tr>
								<tr>
									<td><strong>KEMBALIAN</strong></td>
									<td><input type="hidden" name="textfield3" id="gt" value="<?= $grand; ?>" />
										<input name="balek" type="text" class="form-control    	text-right" style="font-size: 35px;" id="kembali" onkeyup="kembalian();" value="" readonly />
									</td>
								</tr>
								<tr>
									<td><strong>METODE BAYAR</strong></td>
									<td><select name="jenisbayar" class="form-control ">
											<option value="CASH" <?php if (!(strcmp("CASH", htmlentities($row_Faktur['jenisbayar'], ENT_COMPAT, 'utf-8')))) {
																		echo "SELECTED";
																	} ?>>CASH</option>
											<option value="TRANSFER" <?php if (!(strcmp("TRANSFER", htmlentities($row_Faktur['jenisbayar'], ENT_COMPAT, 'utf-8')))) {
																			echo "SELECTED";
																		} ?>>TRANSFER</option>
											<option value="SHOPEEPAY" <?php if (!(strcmp("SHOPEEPAY", htmlentities($row_Faktur['jenisbayar'], ENT_COMPAT, 'utf-8')))) {
																			echo "SELECTED";
																		} ?>>SHOPEEPAY</option>
											<option value="MERCHANT" <?php if (!(strcmp("MERCHANT", htmlentities($row_Faktur['jenisbayar'], ENT_COMPAT, 'utf-8')))) {
																			echo "SELECTED";
																		} ?>>MERCHANT</option>
										</select>
									</td>
								</tr>
								<tr>
									<td><strong>NO. HP </strong><small>(Opsional)</small></td>
									<td><input name="nohp" type="text" class="form-control  text-uppercase" style="font-size: 22px;" />
									</td>
								</tr>
								<tr>
									<td><strong>NAMA PELANGGAN</strong> <br><small>(Opsional)</small></td>
									<td><input name="namapelanggan" type="text" class="form-control  text-uppercase" style="font-size: 22px;" />

										<input name="diskon" type="hidden" class="form-control  text-right" id="textfield2" value="<?= $diskon; ?>" readonly />
									</td>
								</tr>
								<tr>
									<td colspan="2">
										<input type="hidden" name="MM_update" value="formSelesai" />
										<button type="submit" class="btn btn-lg btn-block btn-success">
											<span class="fa fa-print"></span> <strong>SIMPAN TRANSAKSI <strong></button>
									</td>
								</tr>


							</table>
						</div>
					</div>
				</div>
			</form>

		</div>
	<?php } ?>

</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<p class="modal-title text-uppercase" id="exampleModalLabel">Tambahkan Produk Baru</p>
				<small>Fitur ini hanya untuk produk yang belum terdaftar.</small>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="<?php echo $editFormAction; ?>" method="post" name="formBarang" id="formBarang">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-8">
							<div class="form-group">
								<label for="nama">Nama Produk</label>
								<input type="text" name="namaproduk" class="form-control  text-uppercase">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="harga">Harga Jual (Rp.) per Item</label>
								<input type="number" name="harga" class="form-control">
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="qty">Qty (Ketersediaan Awal)</label>
								<input type="number" name="qty" class="form-control">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="satuan">Satuan Produk</label>
								<input type="text" name="satuan" class="form-control text-uppercase">
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Add Cart</button>
				</div>
				<input type="hidden" name="kodeproduk" value="<?= $kodeacak; ?>" />
				<input type="hidden" name="MM_insert" value="formBarang" />
			</form>
		</div>
	</div>
</div>

<script type="text/javascript">
	function kembalian() {
		var tunai = document.getElementById('tanpa-rupiah').value;
		tunai = tunai.replace('.', '');
		var total = document.getElementById('gt').value;
		var balek = parseInt(tunai) - parseInt(total);
		if (!isNaN(balek)) {
			document.getElementById('kembali').value = balek;
		}
	}
</script>



<?php
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "formBarang")) {
	require('faktur.php');
	$Start = mysqli_query($koneksi, "START TRANSACTION") or die(errorQuery(mysqli_error($koneksi)));
	$insertSQL = sprintf(
		"INSERT INTO `produk`(`kodeproduk`,`namaproduk`, `kategori`,`hargadasar`, `hargajual`, `satuan`, `stok`,`addedproduk`, `addbyproduk`) 
				  VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
		GetSQLValueString($koneksi, $_POST['kodeproduk'], "text"),
		GetSQLValueString($koneksi, strtoupper($_POST['namaproduk']), "text"),
		GetSQLValueString($koneksi, 99, "int"),
		GetSQLValueString($koneksi, str_replace(".", "", $_POST['harga']), "double"),
		GetSQLValueString($koneksi, str_replace(".", "", $_POST['harga']), "double"),
		GetSQLValueString($koneksi, $_POST['satuan'], "text"),
		GetSQLValueString($koneksi, $_POST['qty'], "int"),
		GetSQLValueString($koneksi, time(), "int"),
		GetSQLValueString($koneksi, $ID, "int")
	);


	$Result1 = mysqli_query($koneksi, $insertSQL) or die(errorQuery(mysqli_error($koneksi)));

	if ($Result1) {
		$insertSQL = sprintf(
			"INSERT INTO transaksitemp (`faktur`, `tanggal`, `kode`, `nama`, `harga`, `hargadasar`, `diskon`,`qty`, `added`, `addby`, `admintt`, `stt`, `periode`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
			GetSQLValueString($koneksi, $faktur, "text"),
			GetSQLValueString($koneksi, $today, "date"),
			GetSQLValueString($koneksi, $_POST['kodeproduk'], "text"),
			GetSQLValueString($koneksi, strtoupper($_POST['namaproduk']), "text"),
			GetSQLValueString($koneksi, $_POST['harga'], "double"),
			GetSQLValueString($koneksi, $_POST['harga'], "double"),
			GetSQLValueString($koneksi, 0, "double"),
			GetSQLValueString($koneksi, 1, "int"),
			GetSQLValueString($koneksi, time(), "int"),
			GetSQLValueString($koneksi, $ID, "int"),
			GetSQLValueString($koneksi, $nama, "text"),
			GetSQLValueString($koneksi, 'Y', "text"),
			GetSQLValueString($koneksi, $ta, "text")
		);


		$Result1 = mysqli_query($koneksi, $insertSQL) or die(mysqli_error($koneksi));

		if ($Result1) {
			$Commit = mysqli_query($koneksi, "COMMIT") or die(errorQuery(mysqli_error($koneksi)));
			refresh('?page=scan/add');
		}
	}
}
?>